// cloudflare-functions/qb-token.js
// Proxies QB OAuth token exchange — Cloudflare Workers version
// Deploy this as a separate Cloudflare Worker named "sbk-qb-token"

const QB_TOKEN_URL = 'https://oauth.platform.intuit.com/oauth2/v1/tokens/bearer';

const CORS_HEADERS = {
  'Access-Control-Allow-Origin': 'https://app.saybrookelectric.com',
  'Access-Control-Allow-Headers': 'Content-Type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
  'Content-Type': 'application/json',
};

export default {
  async fetch(request) {
    // Handle CORS preflight
    if (request.method === 'OPTIONS') {
      return new Response(null, { status: 204, headers: CORS_HEADERS });
    }

    if (request.method !== 'POST') {
      return new Response('Method Not Allowed', { status: 405, headers: CORS_HEADERS });
    }

    try {
      const { code, redirect_uri, code_verifier, refresh_token, grant_type, client_id, client_secret } =
        await request.json();

      if (!client_id || !client_secret) {
        return new Response(JSON.stringify({ error: 'Missing client_id or client_secret' }), {
          status: 400, headers: CORS_HEADERS,
        });
      }

      const credentials = btoa(`${client_id}:${client_secret}`);

      let body;
      if (grant_type === 'refresh_token') {
        if (!refresh_token) {
          return new Response(JSON.stringify({ error: 'Missing refresh_token' }), {
            status: 400, headers: CORS_HEADERS,
          });
        }
        body = new URLSearchParams({ grant_type: 'refresh_token', refresh_token });
      } else {
        if (!code || !redirect_uri || !code_verifier) {
          return new Response(JSON.stringify({ error: 'Missing code, redirect_uri, or code_verifier' }), {
            status: 400, headers: CORS_HEADERS,
          });
        }
        body = new URLSearchParams({ grant_type: 'authorization_code', code, redirect_uri, code_verifier });
      }

      const response = await fetch(QB_TOKEN_URL, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
          'Authorization': `Basic ${credentials}`,
          'Accept': 'application/json',
        },
        body: body.toString(),
      });

      const data = await response.json();

      return new Response(JSON.stringify(data), {
        status: response.status,
        headers: CORS_HEADERS,
      });

    } catch (err) {
      return new Response(JSON.stringify({ error: 'Internal error', detail: err.message }), {
        status: 500, headers: CORS_HEADERS,
      });
    }
  },
};
