// cloudflare-functions/qb-api.js
// Proxies all QuickBooks API calls — Cloudflare Workers version
// Deploy this as a separate Cloudflare Worker named "sbk-qb-api"

const CORS_HEADERS = {
  'Access-Control-Allow-Origin': 'https://app.saybrookelectric.com',
  'Access-Control-Allow-Headers': 'Content-Type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
  'Content-Type': 'application/json',
};

export default {
  async fetch(request) {
    // Handle CORS preflight
    if (request.method === 'OPTIONS') {
      return new Response(null, { status: 204, headers: CORS_HEADERS });
    }

    if (request.method !== 'POST') {
      return new Response('Method Not Allowed', { status: 405, headers: CORS_HEADERS });
    }

    try {
      const { url, method, token, body } = await request.json();

      if (!url || !token) {
        return new Response(JSON.stringify({ error: 'Missing url or token' }), {
          status: 400, headers: CORS_HEADERS,
        });
      }

      const fetchOptions = {
        method: method || 'GET',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Accept': 'application/json',
          'Content-Type': 'application/json',
        },
      };

      if (body && method === 'POST') {
        fetchOptions.body = JSON.stringify(body);
      }

      const response = await fetch(url, fetchOptions);
      const data = await response.json();

      return new Response(JSON.stringify(data), {
        status: response.status,
        headers: CORS_HEADERS,
      });

    } catch (err) {
      return new Response(JSON.stringify({ error: 'Internal error', detail: err.message }), {
        status: 500, headers: CORS_HEADERS,
      });
    }
  },
};
